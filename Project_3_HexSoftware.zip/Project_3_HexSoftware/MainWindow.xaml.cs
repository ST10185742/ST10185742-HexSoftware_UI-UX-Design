﻿using System.Windows;

namespace Project_3_HexSoftware
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Event handler for "Get Started" button click
        private void GetStartedButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Thank you for choosing BobFlorist! Let’s get started!", "Get Started", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
